public class MyShape {
    private double radius;
    private double volume;
    private  double height;

    public double Myshape(double radius,double height){
        this.volume = volume;
        this.radius = radius;
        this.height = height;

        volume = ((4.0 / 3.0) * Math.PI * Math.pow(radius, 3) / 2) + (1.0 / 3.0) * Math.PI * radius * radius * height;

        return this.volume;
    }
}
