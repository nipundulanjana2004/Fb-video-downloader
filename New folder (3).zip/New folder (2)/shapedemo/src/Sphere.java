public class Sphere {
    private double radius;
    private double volume;


        public double Sphere(double radius) {
            this.radius = radius;
            this.volume = volume;

            volume = (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);

            return this.volume;
        }
}
