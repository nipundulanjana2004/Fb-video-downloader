public class corne {
    private  double radius;
    private  double height;
    private double volume;

    public double Corne(double radius,double height) {
        this.volume = volume;
        this.radius = radius;
        this.height = height;
        volume = (1.0 / 3.0) * Math.PI * radius * radius * height;
        return this.volume;
    }
}
