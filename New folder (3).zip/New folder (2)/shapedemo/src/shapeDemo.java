import java.util.Scanner;
public class shapeDemo {
    public static void main(String [] args){

        Scanner input = new Scanner(System.in);
        int x;
        double r;
        double h;
        do {
            System.out.println("\nPlease Enter the number of shape");
            System.out.println("1. Sphere");
            System.out.println("2. Cone");
            System.out.println("3. Myshape");
            System.out.println("0. Exit");
            System.out.print("Enter your answer: ");
            x = input.nextInt();

            switch (x) {
                case 1:
                    System.out.print("Enter radius of the sphere: ");
                    r = input.nextDouble();
                    Sphere s = new Sphere();
                    System.out.printf("Volume of the Sphere: %.2f\n", s.Sphere(r));
                    break;

                case 2:
                    System.out.print("Enter radius of the cone: ");
                    r = input.nextDouble();
                    System.out.print("Enter height of the cone: ");
                    h = input.nextDouble();
                    corne c = new corne();
                    System.out.printf("Volume of the corne: %.2f\n", c.Corne(r,h));
                    break;

                case 3:
                    System.out.print("Enter radius of the Myshape: ");
                    r = input.nextDouble();
                    System.out.print("Enter height of the Myshape: ");
                    h = input.nextDouble();
                    corne g = new corne();
                    System.out.printf("Volume of the corne: %.2f\n", g.Corne(r,h));
                    break;

                default:
                    System.out.println("Invalid selection. Please try again.");
                    break;
            }
        } while (x != 0);
    }
}
