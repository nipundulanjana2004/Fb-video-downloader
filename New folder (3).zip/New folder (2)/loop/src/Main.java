public class Main {
    public static void main(String[] args) {
        int x;
        int y;
        for (x = 1; x < 5; x++) {
            for (y = 0; x > y;y++){
                    System.out.print("*");
            }
            System.out.println();
        }
    }
}
