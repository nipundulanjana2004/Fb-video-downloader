public class loop2 {
    public static void main(String[] args) {
        int x;
        int y;
        int t;
        for (x = 1; x < 5; x++) {
            for (t = 0; t <= 5; t++) {
                System.out.print(" ");
            }
            for (y = 0; x > y;y++){
                System.out.print(" #");
            }
            System.out.println();
        }
    }
}
