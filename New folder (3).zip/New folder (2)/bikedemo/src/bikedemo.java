public class bikedemo {
    public static void main(String[] args) {
        honda b = new honda();
        b.run();
        b.changegear();
    }
}
