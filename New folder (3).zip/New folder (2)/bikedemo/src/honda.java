public  class honda extends bike {

    @Override
    public void run() {
        System.out.println("honda is running.......");
    }


}
