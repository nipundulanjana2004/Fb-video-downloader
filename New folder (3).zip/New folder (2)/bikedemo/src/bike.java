public abstract class bike {
    public abstract void run();
    bike(){
        System.out.println("bike created");
    }
    void changegear(){
        System.out.println("change gear");
    }
}
