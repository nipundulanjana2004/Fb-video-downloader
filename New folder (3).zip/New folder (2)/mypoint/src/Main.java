public class Main {
    public static void main(String[] args) {
        MyPoint my = new MyPoint();
        my.setX(10);
        my.setY(30);
        my.setXY(10,30);

        System.out.println(my.toString());
        System.out.println(my.distance(10,56));

    }
}