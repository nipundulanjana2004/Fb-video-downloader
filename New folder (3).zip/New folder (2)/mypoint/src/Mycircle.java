public class Mycircle {

}
