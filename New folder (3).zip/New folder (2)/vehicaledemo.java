public class vehicaledemo
{
public static void main(String[] args) {

	//parent class
    //  vehicale v1 = new vehicale();
	//	 v1.start();
	//child class
		car c = new car();
		c.start();
		c.drive();
		System.out.println(c.colour);
		System.out.println(c.wheels);
		c.printtopSpeed();
		System.out.println(c.weight);
    }
}