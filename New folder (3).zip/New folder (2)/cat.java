public class cat extends animal {

    public String color = "sambola";

     cat(){
        System.out.println("Inside Cat DC....");
     }

     cat(String color){
       // color = this.color;
       super(color);
        this.color = color; 
         System.out.println("Inside Cat DC....");       
     }


     @Override
     public void  eat(){
            //access direct super class
            super.eat();
            System.out.println("Cat is eat.....");
    }
}
