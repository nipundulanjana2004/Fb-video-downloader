public class cylinder extends circle{
    private double height = 1.0;

    public cylinder(){

    }

    public cylinder(double height){
        this.height = height;
    }

    public cylinder(double height,double radius){
        super(radius);
        this.height = height;
    }

    public cylinder(double height, double radius, String colour){
        super(radius);
        super(colour);
        this.height = height;
    }

    public double getHeight(){
        return height;
    }

    public void setHeight(double height){
        this.height = height;
    }

    public String toString(){
        return;
    }

    public double getVolume(){
        super(volume);
        return volume();
    }

}
