public class circle {
    private double radius = 1.0;
    private String colour = "red";

    public circle(String colour){

    }

    public  circle(double radius){
            this.radius = radius;
    }

    public  circle(double radius,String colour){
        this.radius = radius;
        this.colour = colour;
    }

    public double getRadius(){

        return radius;
    }

    public void setRadius(double radius){
        this.radius = radius;
    }

    public String getColour(){

        return colour;
    }

    public void setColour(String colour){
        this.colour = colour;
    }

    public String toString(){
            return "";
    }

    public double getArea(){

        return Math.PI*radius*radius;
    }


}
