public class shape {
    public static void main(String[] args) {
        cylinder c1 = new cylinder();
        cylinder c2 = new cylinder(10.0);
        cylinder c3 = new cylinder(7.0, 10.0);

        System.out.println("--- Cylinder c1 ---");
        System.out.println("Radius: " + c1.getRadius());
        System.out.println("Height: " + c1.getHeight());
        System.out.println("Base Area: " + c1.getArea());
        System.out.println("Volume: " + c1.getVolume());
        System.out.println();

        System.out.println("--- Cylinder c2 ---");
        System.out.println("Radius: " + c2.getRadius());
        System.out.println("Height: " + c2.getHeight());
        System.out.println("Base Area: " + c2.getArea());
        System.out.println("Volume: " + c2.getVolume());
        System.out.println();

        System.out.println("--- Cylinder c3 ---");
        System.out.println("Radius: " + c3.getRadius());
        System.out.println("Height: " + c3.getHeight());
        System.out.println("Base Area: " + c3.getArea());
        System.out.println("Volume: " + c3.getVolume());
    }
}
