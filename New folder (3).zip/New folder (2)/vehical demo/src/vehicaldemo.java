public class vehicaldemo {
    public static void main(String[] args) {
        vehical v = new vehical();
        v.start();

        System.out.println(v.colour);

        car c = new car();
        c.start();

        System.out.println(c.colour);

        vehical v2 = new car();
        v2.start();

        System.out.println(v2.colour);

//        car c2 = (car)new vehical();
//        c2.start();

    }
}
