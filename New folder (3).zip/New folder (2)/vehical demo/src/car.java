public class car extends vehical{
    public String colour = "red";
    public void start(){
        System.out.println("Car is starting");
    }
}
