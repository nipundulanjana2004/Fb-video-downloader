public class vehical {

    public String colour = "white";
    public void start(){
        System.out.println("Vehical is Starting...");
    }
}
