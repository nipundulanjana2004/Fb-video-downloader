public class animaldemo {
    public static void main(String[] args){

       // cat c = new cat();
      //  c.eat();

        cat  c = new cat("white");
        System.out.println(c.color);
    }
}


//c c = (c) new b();