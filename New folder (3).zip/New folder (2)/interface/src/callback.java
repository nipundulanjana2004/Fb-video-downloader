public interface callback {
    public void callback(int param);
}
