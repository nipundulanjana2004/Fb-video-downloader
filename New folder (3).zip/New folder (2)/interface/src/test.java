public class test {
    public static void main(String[] args) {
        Mydocument doc = new Mydocument();
        doc.printing();
    }
}
