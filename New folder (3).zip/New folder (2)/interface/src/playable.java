public interface playable {
    void play();
    default void quit(){
        System.out.println("Sorry can not play again........");
    }
}
