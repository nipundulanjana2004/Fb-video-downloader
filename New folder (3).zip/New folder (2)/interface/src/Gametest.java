public class Gametest {
    public static void main(String[] args) {
        Game g = new Game();
        g.play();
        g.quit();
    }
}
