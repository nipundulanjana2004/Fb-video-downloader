public class Game implements playable{

    @Override
    public void play() {
        System.out.println("Good luck!");
    }


//    @Override
//    default void quit(){
//        System.out.println("Sorry can not play again........");
//    }

}

//mark