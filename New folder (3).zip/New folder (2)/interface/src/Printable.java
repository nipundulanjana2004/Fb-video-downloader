public interface Printable {
    void printing();
}