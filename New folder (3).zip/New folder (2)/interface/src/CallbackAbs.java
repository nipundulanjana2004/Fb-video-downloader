  abstract class CallbackAbs implements callback{
    int a,b;
    void show(){
        System.out.println(a + "" + b);
    }
}
