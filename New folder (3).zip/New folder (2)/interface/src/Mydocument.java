public class Mydocument implements Printable{
    @Override
    public void printing() {
        System.out.println("Printing the document");
    }
}
