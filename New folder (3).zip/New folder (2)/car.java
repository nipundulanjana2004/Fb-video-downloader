public class car extends vehicale 
{

    //instance Filed Hiding
    public  String  colour = "red";

    //adding new field
    public int wheels = 4;

    //static field hiding
    public static double weight = 1000.00;
    @Override
    //instances method hiding
    public void start(){
    System.out.println("car is starting....");
		
}

//adding new behaviour
	public void drive(){
	System.out.println("car is driving...");

}

//instance method hiding
public static void printtopSpeed(){
		System.out.println("Top speed is 50");
}

}