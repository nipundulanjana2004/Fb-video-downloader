public class animal {

    animal(){
        System.out.println("Inside Animal DC........");
    }

    animal(String something){
        System.out.println("Inside Animal DC " + something);
    }

    public void  eat(){
         System.out.println("Animal is eat.........");
    }
}
