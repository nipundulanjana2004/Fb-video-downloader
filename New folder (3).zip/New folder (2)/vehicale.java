public class vehicale {

public  String  colour = "white";
public static double weight = 200.00;

	public   void start(){
System.out.println("starting....");
}

public static void printtopSpeed(){
		System.out.println("Top speed is 50");
}

}