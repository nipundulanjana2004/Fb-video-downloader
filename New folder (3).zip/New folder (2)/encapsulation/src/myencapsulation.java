public class myencapsulation {
    private String name;

    public void setName(String name){
        this.name = name;
    }

    public String getName (){
        //name = name + "Dulanjana";
        return name;
    }
}
