public class encapsulationdemo {
    public static void main(String[] args) {
        myencapsulation my = new myencapsulation();
        my.setName("Nipun");
        my.getName();
        System.out.println(my.getName());
    }
}
