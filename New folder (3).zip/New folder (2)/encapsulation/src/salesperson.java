public class salesperson {
    private String name;
    private int id;
    private float commitionRate;
    private double salary;

    public void setName(String name) {
        this.name = name;
    }

    public void setCommitionRate(float commitionRate) {
        this.commitionRate = commitionRate;
    }

    public String getName() {
        return name;
    }

    public float getCommitionRate() {
        return commitionRate;
    }

    salesperson(String name, int id, float commitionRate, double salary) {
       setName(name);
       this.id = id;
       setCommitionRate(commitionRate);
    }
}
