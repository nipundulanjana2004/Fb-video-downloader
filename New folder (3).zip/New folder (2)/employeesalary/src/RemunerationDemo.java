public class RemunerationDemo {
    public static void main(String[] args) {
        Remuneration r = new Remuneration();
        r.calcSalary();
        r.printSalary();
    }
}
