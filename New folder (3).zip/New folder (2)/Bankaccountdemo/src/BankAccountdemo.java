public class BankAccountdemo {
    public static void main(String[] args) {
        BankAccount bankAccount = new BankAccount();
        bankAccount.setAccountNumber(123456);
        bankAccount.deposite(5000);
        bankAccount.withdraw(3000);
        bankAccount.getBalance();
        bankAccount.deposite(5000);
    }
}
