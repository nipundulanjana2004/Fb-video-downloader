public class BankAccount {
    private int accountNumber;
    private String accountholderName;
    private double balance;

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountholderName() {
        return accountholderName;
    }

    public void setAccountholderName(String accountholderName) {
        this.accountholderName = accountholderName;
    }

    public double getBalance() {
        return balance;
    }

    public void deposite(double amount){
        this.balance = + amount;
        System.out.println("Deposited " + amount + " to " + accountNumber);
    }

    public void withdraw(double amount){
        this.balance -= amount;
        System.out.println("Withdrawn " + amount + " to " + accountNumber);
    }
}
