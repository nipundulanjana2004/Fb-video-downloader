public class Book {
    private String name;
    private Author[] author;
    private double price;
    private int qtylnstock;

    public Book(String name, Author[] author, double price) {
        this.name = name;
        this.author = author;
        this.price = price;
    }

    public Book(String name, Author[] author, double price, int qtylnstock) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.qtylnstock = qtylnstock;
    }

    public String getName() {
        return name;
    }

    public Author[] getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQtylnstock() {
        return qtylnstock;
    }

    public void printAuthors() {
        for (int i = 0; i < author.length; i++) {
            System.out.print(author[i].getName());
            if (i < author.length - 1) {
                System.out.println("\t");
            }
        }
        System.out.println();
    }

    public String toString() {
        return "'" + name + "' by " + author.length + " authors";
    }
}
