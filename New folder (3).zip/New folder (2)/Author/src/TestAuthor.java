public class TestAuthor {
    public static void main(String[] args) {

        Author[] authors = new Author[2];
        authors[0] = new Author("Nipun", "nipun6789@gmail.com", 'M');
        authors[1] = new Author("Jane Doe", "jane@example.com", 'F');


        Book b = new Book("Java Programming", authors, 49.99, 100);


        System.out.println("Book Details: " + b.toString());


        System.out.print("Authors list: ");
        b.printAuthors();
    }
    }

