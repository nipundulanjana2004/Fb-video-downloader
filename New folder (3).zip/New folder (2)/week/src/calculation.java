public class calculation {

//    void sum(int a, double b) {
//        System.out.println(a + b);
//    }

//    void sum(int a, int b, int c) {
//        System.out.println(a + b + c);
//    }

//    void sum(double a, int b) {
//        System.out.println(a + b);
//    }

    void sum(double a, double b, double c, double d) {
        System.out.println(a + b + c + d);
    }

    public static void main(String[] args) {
        calculation cal = new calculation();
//        cal.sum(1, 2.0);
//        cal.sum(1, 2, 3);
//        cal.sum(2.0, 3);
          cal.sum(10.3,5,3.4,8);

    }
}
