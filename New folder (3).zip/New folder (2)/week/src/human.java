public class human {
    public void eat(){
        System.out.println("eat");
    }
}

class boy extends human{
    public void eat(){
        System.out.println("boy eat");
    }
    public static void main(String[] args) {
        boy nimal = new boy();
        nimal.eat();
    }
}
