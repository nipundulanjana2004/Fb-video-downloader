public abstract class Square extends FlatShape{

    public double baseLength = 1.0;

    public Square(){

    }

    Square (double baseLength){
        this.baseLength = baseLength;
    }

    public double getBaseLength(){
        return 0;
    }

    public void setBaseLength(double baseLength){
        System.out.println(baseLength);
    }

    public double getArea(double x){
        return Math.pow(x,2);
    }

}
