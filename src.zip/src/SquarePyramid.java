public class SquarePyramid {

    private double baseLength;
    double height = 1.0;

    SquarePyramid(){

    }

    SquarePyramid(double height){
        this.height = height;

    }

    SquarePyramid(double baseLength, double height){
        super();
        this.baseLength = baseLength;
        this.height = height;
    }

    double getHeight(){
        return 0;
    }

    void setHeight(double height){
        System.out.println(height);
    }

    double getVolume(){
        return 0;
    }

}
