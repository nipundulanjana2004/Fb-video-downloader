public class Demo {
    public static void main(String[] args) {


        SquarePrism c1 = new SquarePrism();
        SquarePrism sp1 = new SquarePrism();
        SquarePrism sp2 = new SquarePrism(10.0);
        SquarePrism sp3 = new SquarePrism(5.0,10.0);
        SquarePyramid spy1 = new SquarePyramid();
        SquarePyramid spy2 = new SquarePyramid(10.0);
        SquarePyramid spy3 = new SquarePyramid(5.0,10.0);

        System.out.println(c1.baseLength + sp1.height + c1.getArea() + c1.getVolume());
        System.out.println(sp2.baseLength + sp2.height + sp2.getArea() + sp2.getVolume());
        System.out.println(sp3.baseLength + sp3.height + sp3.getArea() + sp3.getVolume());
        System.out.println(spy1.baseLength + spy1.height + spy1.getArea() + spy1.getVolume());
        System.out.println(spy2.baseLength + spy2.height + spy2.getArea() + spy2.getVolume());


    }
}
