public class SquarePrism extends Square{

    public double height = 1.0;
    /*public double x;
    public double h;
*/
    SquarePrism(){

    }

    SquarePrism(double height){
        this.height = height;
    }

    SquarePrism(double baseLength, double height){
        super(baseLength);
        this.baseLength = baseLength;
        this.height = height;
    }

    double getHeight(){
        return 0;
    }

    void setHeight(double height){
        System.out.println(height);
    }

    public double getArea(){
        return 0;
    }

    @Override
    public double getVolume() {
        return super.getVolume();
    }
}
