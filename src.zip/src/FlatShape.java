public abstract class FlatShape {


    public FlatShape() {
    }

    public double getArea(){
        return 0;
    }

    public double getVolume(){
        return 0;
    }
}
